#!/usr/bin/env python
# -*- coding: utf-8 -*-
 
"""
Copyright (c) 2017 zaizhizhuang.  All rights reserved.
This program is free software; you can redistribute it and/or modify.
"""
 
import rospy
from std_msgs.msg import String
 
import urllib.request
import urllib, sys
import ssl
import json
 
 
import signal
import sys
 
from pprint import pprint
 
class baidu_unit_talk_main():
 def __init__(self):
  self.define()
 
  rospy.Subscriber(self.token_topic , String , self.set_token)
  #wait for token...
  while not self.access_token:
   rospy.logwarn('get token Retrying ...')
   rospy.sleep(1.0)
   self.access_token=rospy.get_param('/baidu_unit_token_string', '')
  #listen topic
  rospy.Subscriber(self.listen_topic , String , self.get_say)
  #zzz test
  #self.load("今天北京天气怎么样？")
  rospy.spin()
 
 
 
 
 
 
 def get_say(self,data):
  self.load(data.data)
 
 
 def load(self,data):
 
  url = 'https://aip.baidubce.com/rpc/2.0/solution/v1/unit_utterance?access_token=' + self.access_token
  post_data = "{\"scene_id\":"+str(self.scene_id)+",\"query\":\""+str(data)+"\",\"session_id\":\""+str(self.session_id)+"\"}"
  print(post_data)
  request = urllib.request.Request(url, post_data)
  request.add_header('Content-Type', 'application/json; charset=UTF-8')
  #request.add_header('Content-Type', 'application/json')
  response = urllib.request.urlopen(request)
  content = response.read()
  if (content):
   print(content)
   #s = json.dumps(data)
   s1 = json.loads(content)
   #test
   #pprint(s1)
   if (s1[u"result"][u"session_id"]):
    self.session_id=s1[u"result"][u"session_id"]
   if (s1[u"result"][u"action_list"][0][u"say"]):
    self.words=s1[u"result"][u"action_list"][0][u"say"]
    self.say.publish(self.words)
    print (self.words)
 
 def define(self):
  self.say=rospy.Publisher('speak_string', String, queue_size=1)
  if not rospy.has_param('~baidu_unit_scene_id'):
   rospy.set_param('~baidu_unit_scene_id', 'cKoOeVGv')
  if not rospy.has_param('~baidu_unit_token_topic'):
   rospy.set_param('~baidu_unit_token_topic', 'baidu_unit_token_string')
  if not rospy.has_param('~baidu_unit_listen_topic'):
   rospy.set_param('~baidu_unit_listen_topic', 'baidu_unit_listen_string')
 
  self.token_topic=rospy.get_param('~baidu_unit_token_topic')
  self.listen_topic=rospy.get_param('~baidu_unit_listen_topic')
  self.scene_id=rospy.get_param('~baidu_unit_scene_id')
  self.access_token=''
  self.session_id=''
 
 def set_token(self,data):
  print(data)
  if data.data :
   self.access_token=data.data
  else:
   pass
 
 
 
 
def quit(signum, frame):
 print("You choose to stop me")

 sys.exit(0)
if __name__=="__main__":
 try:
  signal.signal(signal.SIGINT, quit)
  signal.signal(signal.SIGTERM, quit)
  rospy.init_node('baidu_unit_talk')
  rospy.loginfo("initialization  baidu_unit talking")
  baidu_unit_talk_main()
  rospy.loginfo("process done and quit")
 except(Exception,exc):
  print(exc)

